# Iteration 05：我如何获得和调配能力

## 初始假设

我内置一批工具，比如文件读写、Git、测试、模型调用，然后就可以开发 AgentApp。

## 自我质疑

如果用户想生成一个连接企业系统的 AgentApp 呢？如果要用 MCP 接工具呢？如果要支持新的测试框架、部署平台、数据源、浏览器自动化、文档系统呢？

如果能力写死，我会很快变小。

## 发现

我需要一个能力织网：Capability Fabric。

它包括：

- MCP Connectors：连接外部工具与数据源。
- Skills：可复用专业能力包。
- `.agent`：Agent 定义文件。
- Plugins：扩展 AgentArbor 本体。
- Built-in Tools：高价值内置能力。
- Capability Router：根据目标自动调配能力。

我的“无限能力”不是出生时什么都会，而是我能不断发现、安装、验证、组合和沉淀新能力。

## 迭代结论

能力不能绑死在 Agent 身上，应被抽象为可声明、可路由、可验证、可治理的系统资产。

## 本轮决策

将 Capability Fabric 作为 AgentArbor 的核心层之一。
