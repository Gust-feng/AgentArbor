# Capability Manifest 设计

Capability 是 AgentArbor 能力系统的基础声明。

## 示例

```yaml
id: git.commit
name: Git Commit
kind: built-in-tool
riskLevel: medium

permissions:
  requires:
    - workspace.write
    - git.write

inputSchema:
  type: object
  required:
    - message
    - files

outputSchema:
  type: object
  required:
    - commitHash
    - summary

governance:
  requiresTestsPassing: true
  requiresReviewForMajorChange: true
  userConfirmation: false

failureModes:
  - Commit includes unintended files.
  - Commit message does not explain purpose.
  - Tests were not run before commit.
```

## Capability 类型

- built-in-tool；
- mcp-tool；
- skill；
- plugin；
- user-defined；
- generated。

## 风险等级

- low：读操作或无副作用。
- medium：写文件、commit、安装依赖。
- high：删除、外部执行、联网、重生、分支迁移。

## 设计目的

让所有能力可见、可授权、可治理、可验证。
