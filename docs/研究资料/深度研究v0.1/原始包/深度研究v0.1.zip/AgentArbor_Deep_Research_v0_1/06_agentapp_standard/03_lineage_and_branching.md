# Lineage 与分化

## 1. Lineage 是什么

Lineage 是 AgentApp 的生命谱系。

它记录：

- 从哪里来；
- 为什么分化；
- 分化后目标是什么；
- 继承了什么；
- 废弃了什么；
- 当前属于第几代。

## 2. Git 与 Lineage

Git branch 是技术结构。Lineage 是语义结构。

AgentArbor 需要把二者结合：

```text
main
├─ branch/personal-edition
├─ branch/enterprise-edition
└─ rebirth/v2-runtime
```

## 3. 分化触发

分化通常由这些情况触发：

- 用户希望保留当前版本并探索新方向；
- 新需求与旧主线冲突；
- 同一 AgentApp 面向不同用户群；
- 需要实验性架构；
- 需要企业版、轻量版、本地版。

## 4. 分化记录

每次分化应生成：

```text
docs/evolution/branch-enterprise-edition.md
```

内容：

- 分化原因；
- 父版本；
- 新目标；
- 继承能力；
- 新增能力；
- 废弃能力；
- 风险；
- 验收标准。

## 5. Lineage View

Workbench 应展示：

```text
DailyReportAgent
├─ main
│  ├─ v1 Basic Daily Report
│  └─ v2 Weekly Summary
├─ personal-insight
├─ enterprise-team
└─ rebirth/v2-architecture
```

## 6. 关键结论

分化不是复制粘贴，而是在保留血缘的前提下长出新枝条。
