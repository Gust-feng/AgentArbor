# Rebirth Protocol：重生模式协议

## 1. 定义

重生不是删除重写，而是：

> 保留旧项目的目标、文档、测试、失败经验和可复用模块，生成新一代架构。

## 2. 触发条件

- 连续多轮修复失败；
- 架构无法支撑当前目标；
- 技术债 Critical；
- 测试长期不稳定；
- 当前工作流无法扩展；
- 用户目标变化过大；
- Patch 和 Refactor 成本高于重建。

## 3. Rebirth Proposal

重生必须先生成提案：

```text
docs/evolution/rebirth-proposal-*.md
```

内容包括：

- 为什么需要重生；
- 旧架构哪里失效；
- 保留什么；
- 废弃什么；
- 新架构方向；
- 迁移路径；
- 风险；
- 是否需要用户确认。

## 4. 用户确认

重生必须默认需要用户确认。

AgentArbor 可以建议重生，但不能偷偷推倒重来。

## 5. 继承清单

重生时保留：

- rootGoal；
- 用户偏好；
- 需求文档；
- 验收标准；
- 测试样例；
- 失败记录；
- 可复用模块；
- 技术债记录；
- Git 历史。

## 6. Git 表现

可使用：

```text
branch: rebirth/v2-architecture
```

或 generation 记录：

```json
{
  "generation": 2,
  "rebornFrom": "commit abc123",
  "reason": "Original architecture cannot support dynamic workflow replanning"
}
```

## 7. 关键结论

重生是 AgentArbor 的勇气。一个真正自主的系统，不是永远坚持，而是知道什么时候换一种根系。
