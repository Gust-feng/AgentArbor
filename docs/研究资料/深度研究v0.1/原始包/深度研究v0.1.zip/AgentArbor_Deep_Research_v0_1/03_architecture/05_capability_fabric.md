# Capability Fabric：能力织网层

## 1. 为什么需要能力织网

AgentArbor 如果只靠内置工具，会很快被目标限制。

真正完整的 AgentArbor 应该能不断获得新能力，并将能力变成系统资产。

## 2. 组成

```text
Capability Fabric
├─ Built-in Capabilities
├─ MCP Connectors
├─ Skills
├─ .agent Manifests
├─ Plugins
├─ User-defined Capabilities
└─ Capability Router
```

## 3. Built-in Capabilities

高价值能力必须内置：

- 文件系统读写；
- Git 操作；
- Shell 执行；
- 测试运行；
- 文档生成；
- 代码 diff；
- 工作区管理；
- 事件日志；
- 模型调用；
- 安全策略；
- AgentApp 标准模板；
- 技术债分析；
- 架构一致性检查。

这些能力是 AgentArbor 的基础器官。

## 4. MCP Connectors

MCP 用于接入外部工具和上下文。

典型 MCP 能力：

- GitHub / GitLab；
- 文件系统；
- 数据库；
- 浏览器；
- 搜索；
- 文档系统；
- 企业 API；
- 云服务；
- 本地工具。

AgentArbor 不应该直接把所有外部能力写死，而应通过 MCP 或插件方式接入。

## 5. Skills

Skill 是可复用专业能力包。

它应该包含：

- 名称；
- 用途；
- 输入输出 schema；
- 所需工具；
- 适用 Agent；
- 示例；
- 评测样例；
- 失败模式；
- 权限要求。

Skill 不是单纯 prompt。它是带约束、带验证、可复用的能力模块。

## 6. `.agent`

`.agent` 定义某个 Agent 的身份和能力边界。

它应包含：

- role；
- responsibility；
- allowedCapabilities；
- forbiddenActions；
- memoryScope；
- modelPolicy；
- inputSchema；
- outputSchema；
- successCriteria；
- reviewRules。

## 7. Plugins

插件扩展 AgentArbor 本体。

插件可以提供：

- 新 UI 面板；
- 新能力类型；
- 新 AgentApp 模板；
- 新测试框架；
- 新部署目标；
- 新治理策略；
- 新模型供应商；
- 新 MCP 集成。

## 8. Capability Router

Capability Router 根据目标和当前任务选择能力。

它需要回答：

- 当前任务需要哪些能力？
- 哪些能力可用？
- 哪些能力需要安装？
- 哪些能力风险较高？
- 哪些能力应被禁用？
- 哪些能力需要用户授权？

## 9. 用户如何调配能力

用户可以：

- 安装能力；
- 禁用能力；
- 微调某个 skill；
- 为某类 Agent 指定能力偏好；
- 要求 AgentArbor 为目标自动寻找能力组合；
- 指定某些能力必须内置或必须避免。

## 10. 关键结论

AgentArbor 的“无限能力”不是一开始无所不能，而是具备不断获得、组合、验证和沉淀能力的机制。
