# Codex Prompt：后端自主内核

请实现 AgentArbor 的后端自主内核。

## 必须模块

- EventBus
- RunState
- WorkflowIR
- AutonomyKernel
- GoalManager
- StateObserver
- OptionGenerator
- DecisionEngine
- ReflectionEngine
- EvolutionDecider

## 设计要求

1. 所有状态变化必须发事件。
2. WorkflowIR 必须可动态修改。
3. DecisionEngine 必须支持多候选动作。
4. EvolutionDecider 至少支持 Patch、Refactor、Redirect、Branch、RebirthProposal。
5. 用户中断必须进入 Suspended State。
6. 不要把具体 UI 逻辑写进 core。

## 输出

- TypeScript 类型定义。
- 核心类或服务。
- 单元测试。
- 示例运行流程。
