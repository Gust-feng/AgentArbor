# Execution Runtime：执行运行时

## 1. 定义

Execution Runtime 是 AgentArbor 的手。

它负责把计划、任务和 Agent 决策落到文件、命令、测试和 Git 上。

## 2. 能力

执行运行时应支持：

- 创建工作区；
- 读取和修改文件；
- 调用模型；
- 调用 MCP / skills / plugins；
- 执行 shell 命令；
- 运行测试；
- 生成 diff；
- 执行 Git commit / branch；
- 保存 checkpoint；
- 恢复中断运行；
- 记录事件；
- 执行沙箱策略。

## 3. 可中断与可恢复

AgentArbor 必须支持用户中途停止自主迭代。

因此每次运行都应该有：

- runId；
- 当前任务图；
- 当前任务状态；
- 工作区快照；
- 事件历史；
- Git 状态；
- 未完成动作；
- 下次恢复建议。

## 4. 事件化执行

每个执行动作都应转化为事件：

```text
run.started
agent.started
task.created
task.completed
file.changed
test.failed
test.passed
git.committed
plan.revised
branch.created
rebirth.proposed
user.interrupted
```

事件是 UI 实时展示的基础，也是后续反思和演化的依据。

## 5. Checkpoint

执行过程中应设置 checkpoint：

- 计划冻结后；
- 阶段开始前；
- 重大文件修改前；
- 测试通过后；
- Git commit 后；
- 用户中断时。

Checkpoint 让系统可以恢复、回滚、对比和分化。

## 6. 执行权限

运行时不能无限制执行命令。

需要由 Governance System 控制：

- 允许哪些目录；
- 允许哪些命令；
- 是否允许删除；
- 是否允许联网；
- 是否允许安装依赖；
- 是否需要用户确认；
- 是否运行在沙箱中。

## 7. 关键结论

Execution Runtime 不是简单工具调用器，而是 AgentArbor 的可追踪行动层。每次行动都必须可记录、可验证、可恢复。
