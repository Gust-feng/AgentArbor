# Autonomy Kernel：自主内核

## 1. 定义

Autonomy Kernel 是 AgentArbor 的心脏。

它不负责写代码，而负责决定：

> 当前状态下，系统最值得走的下一步是什么？

## 2. 核心组成

```text
Autonomy Kernel
├─ Goal Manager
├─ State Observer
├─ Gap Analyzer
├─ Option Generator
├─ Decision Engine
├─ Reflection Engine
└─ Evolution Decider
```

## 3. Goal Manager

管理用户目标、当前目标、历史目标和目标变化。

目标不是一句 Prompt，而是一组可被追踪的结构：

- rootGoal：原始目标；
- currentGoal：当前目标；
- constraints：边界；
- acceptance：验收条件；
- priority：优先级；
- userIntentHistory：用户意图变化。

## 4. State Observer

观察当前项目状态：

- 文档状态；
- 代码状态；
- 测试状态；
- Git 状态；
- 任务图状态；
- Agent 状态；
- 能力状态；
- 技术债状态；
- 用户中断状态。

一个不能看见自己的系统，不可能自主。

## 5. Gap Analyzer

分析目标与当前状态之间的差距。

差距不只是“还缺哪些功能”，还包括：

- 架构是否支撑目标；
- 能力是否足够；
- 测试是否覆盖；
- 文档是否过期；
- 目标是否变化；
- 技术债是否阻塞；
- 当前计划是否失效。

## 6. Option Generator

生成下一步候选动作。

候选动作包括：

- continue：继续执行当前任务图；
- repair：修复局部失败；
- refactor：重构结构；
- replan：重新规划；
- expandCapability：添加能力；
- branch：分化；
- redirect：转向；
- rebirth：重生；
- pause：暂停；
- askUser：请求用户确认；
- complete：完成。

这一步是自主性的关键。没有多选项，就没有判断权。

## 7. Decision Engine

对候选动作进行评分。

评分维度：

- goalImpact：对目标推进程度；
- risk：风险；
- reversibility：可逆性；
- cost：成本；
- confidence：成功置信度；
- debtImpact：技术债影响；
- userAlignment：是否符合用户意图；
- governanceStatus：是否允许。

## 8. Reflection Engine

每轮执行后进行复盘：

- 这轮是否推进目标？
- 是否引入新问题？
- 当前计划是否仍可靠？
- 是否需要更新文档？
- 是否需要提交 Git？
- 是否需要改变 Agent 组织？

## 9. Evolution Decider

决定系统演化动作：Patch、Refactor、Redirect、Branch、Rebirth。

这不是普通状态跳转，而是对整个项目生命形态的判断。

## 10. 自主性的判据

AgentArbor 只有在满足以下条件时，才可以说自己具备自主性：

1. 能感知当前状态。
2. 能生成多个行动选项。
3. 能解释选择理由。
4. 能执行并验证结果。
5. 能在失败后改变策略。
6. 能在方向变化时重规划。
7. 能在架构失效时提出重生。
8. 能在关键风险点请求用户确认。

## 11. 关键结论

AgentArbor 的自主性不是“自动干活”，而是：

> 在目标、状态、反馈、能力和治理之间，持续选择最值得走的下一条路。
