# 文件夹内容清单

## 01_foundation

- `01_vision.md`：AgentArbor 的产品愿景与精神内核。
- `02_design_principles.md`：系统设计原则。
- `03_non_goals.md`：明确不做什么。
- `04_glossary.md`：核心概念词典。

## 02_research_iterations

模拟“未出生的 AgentArbor”对自己进行六轮自助迭代研究。

- `iteration_01_identity.md`：我是谁。
- `iteration_02_autonomy.md`：我凭什么自主。
- `iteration_03_workflow.md`：我为什么需要工作流但不能被模板绑死。
- `iteration_04_lifecycle.md`：我如何出生、维护、分化、重生。
- `iteration_05_capabilities.md`：我如何获得和调配能力。
- `iteration_06_final_shape.md`：我最终应该长成什么。

## 03_architecture

- `01_system_overview.md`：整体系统架构。
- `02_autonomy_kernel.md`：自主内核。
- `03_dynamic_workflow_meta_loop.md`：动态工作流与元循环。
- `04_agent_organization.md`：Agent 组织结构。
- `05_capability_fabric.md`：MCP、skills、.agent、插件与能力路由。
- `06_execution_runtime.md`：执行运行时。
- `07_verification_system.md`：验证系统。
- `08_evolution_system.md`：演化系统。
- `09_governance_system.md`：治理系统。
- `10_workbench_ui.md`：Workbench 产品形态。

## 04_models_and_schemas

- `01_arbor_json.md`：`arbor.json` 元信息文件设计。
- `02_agent_manifest.md`：`.agent` 文件设计。
- `03_skill_manifest.md`：Skill 设计。
- `04_capability_manifest.md`：能力声明。
- `05_workflow_ir.md`：动态任务图 / Workflow IR。
- `06_event_model.md`：事件模型。
- `07_state_machine.md`：状态机。

## 05_decision_frameworks

- `01_evolution_decision_matrix.md`：Patch / Refactor / Redirect / Branch / Rebirth 判断矩阵。
- `02_anti_local_optimum.md`：避免局部最优与技术债。
- `03_user_interruption_and_resume.md`：用户主动停止后的后续迭代策略。
- `04_technical_debt_protocol.md`：技术债协议。
- `05_rebirth_protocol.md`：重生模式协议。

## 06_agentapp_standard

- `01_standard_folder_structure.md`：AgentApp 标准目录。
- `02_generated_agentapp_contract.md`：被孕育 AgentApp 的契约。
- `03_lineage_and_branching.md`：谱系与分化。

## 07_roadmap

- `01_mvp_scope.md`：第一版范围。
- `02_full_shape_roadmap.md`：完整形态路线。
- `03_risks.md`：关键风险。

## 08_diagrams

Mermaid 图文件。

## 09_codex_prompts

给 Codex / AI 开发工具使用的开发简报。
