# Verification System：验证系统

## 1. 为什么验证是核心

没有验证，AgentArbor 只会生成。生成不等于完成。

验证系统决定什么可以留下，什么必须修复，什么应该回滚，什么需要重构。

## 2. 验证类型

```text
Verification System
├─ Functional Verification
├─ Test Verification
├─ Build Verification
├─ Type Verification
├─ Architecture Verification
├─ Goal Verification
├─ Capability Verification
├─ Security Verification
├─ Documentation Verification
└─ Debt Verification
```

## 3. Functional Verification

检查功能是否满足目标和验收条件。

## 4. Test Verification

运行测试，生成失败原因，决定是否进入 Repair。

## 5. Architecture Verification

检查是否违反架构不变量：

- core 不依赖 UI；
- model-router 不直接操作文件；
- workflow engine 不直接调用具体模型；
- tool call 必须经过 capability router；
- Git commit 不能绕开 GitAgent；
- 测试失败不能进入正式阶段提交。

## 6. Goal Verification

检查当前产物是否仍然贴合用户目标。

这很重要，因为 AI 常常能把某个局部做得很漂亮，却离原目标越来越远。

## 7. Capability Verification

检查 AgentApp 是否真正具备声明的能力。

例如，一个 AgentApp 声称支持 MCP 数据库连接，就必须有对应配置、测试样例、失败处理和权限说明。

## 8. Debt Verification

检查技术债：

- 重复代码；
- 模块过大；
- 测试缺口；
- 文档过期；
- 隐式依赖；
- 不可逆修改；
- 难以扩展的架构。

## 9. 验证结果

验证结果可以触发：

- continue；
- repair；
- refactor；
- replan；
- askUser；
- commit；
- branch；
- rebirth。

## 10. 关键结论

验证系统是 AgentArbor 的自然选择机制。生成物不是因为被生成就存在，而是因为通过验证才被保留。
