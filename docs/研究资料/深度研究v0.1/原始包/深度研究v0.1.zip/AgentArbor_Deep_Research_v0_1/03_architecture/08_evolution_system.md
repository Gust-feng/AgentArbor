# Evolution System：演化系统

## 1. 定义

Evolution System 负责 AgentApp 的生命周期动作。

它让 AgentArbor 不止能生成，还能维护、修剪、转向、分化和重生。

## 2. 五级演化动作

```text
Level 1 Patch      小修补
Level 2 Refactor   重构
Level 3 Redirect   转向
Level 4 Branch     分化
Level 5 Rebirth    重生
```

## 3. Patch

适用于局部问题。

例子：

- 测试失败；
- 类型错误；
- 输出格式错误；
- 局部 bug。

## 4. Refactor

适用于结构变差但目标不变。

例子：

- 模块边界模糊；
- 代码重复；
- 测试难写；
- 某些文件过大；
- 技术债开始阻塞后续扩展。

## 5. Redirect

适用于目标方向改变。

例子：

- 日报 Agent 改成生产力分析系统；
- 简单工具变成平台；
- 用户改变目标用户或使用场景。

Redirect 必须先改文档和计划，再改代码。

## 6. Branch

适用于新需求和旧主线都合理，但不适合放在同一版本。

例子：

- 个人版和企业版；
- 稳定版和实验版；
- Web 版和本地桌面版；
- 轻量版和完整功能版。

## 7. Rebirth

适用于旧架构不再适合目标。

例子：

- 连续修复失败；
- 旧架构无法支持动态任务图；
- 技术债超过阈值；
- 测试长期不稳定；
- 新目标与旧根架构冲突。

## 8. 演化记录

所有演化都应进入：

```text
docs/evolution/
├─ patch-*.md
├─ refactor-*.md
├─ redirect-*.md
├─ branch-*.md
└─ rebirth-*.md
```

## 9. Lineage

每个分支和重生版本都要记录血缘：

- parent；
- branch；
- generation；
- rebornFrom；
- reason；
- inheritedAssets；
- discardedAssets。

## 10. 关键结论

AgentArbor 的演化能力不是附加功能，而是它与普通 AI 生成器的根本区别。
