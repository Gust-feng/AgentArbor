# Codex Prompt：Workbench UI

请实现 AgentArbor Workbench 的第一版 UI。

## 目标

UI 是驾驶舱，不是逻辑中心。

它应从后端 snapshot 和 events 渲染状态。

## 必须区域

- 左侧：文件树 / 项目结构；
- 中间：Agent Graph / 计划 / diff；
- 右侧：Git Timeline / 测试状态；
- 底部：Execution Feed / 日志；
- 顶部：运行状态 / 当前迭代 / 停止按钮。

## 事件驱动

UI 必须根据事件更新，而不是写死工作流步骤。

事件包括：

- agent.started；
- task.completed；
- file.changed；
- test.failed；
- git.committed；
- evolution.rebirth_proposed；
- user.interrupted。

## 输出

- React / TypeScript 组件。
- 状态管理。
- mock event stream。
- 后续替换为 SSE / WebSocket 的接口。
