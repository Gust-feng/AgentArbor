# Governance System：治理系统

## 1. 定义

Governance System 是 AgentArbor 的法律。

它不负责创作，而负责裁决：什么能做，什么不能做，什么必须确认，什么必须回滚。

## 2. 为什么需要治理

AgentArbor 越自主，越需要治理。

没有治理的自主，会变成危险的自由发挥。

## 3. 治理范围

```text
Governance System
├─ Permission Policy
├─ File Policy
├─ Command Policy
├─ Model Policy
├─ Capability Policy
├─ Git Policy
├─ User Confirmation Policy
├─ Retry Policy
└─ Rebirth Policy
```

## 4. Permission Policy

定义 Agent 可以做什么：

- 哪些 Agent 可以改代码；
- 哪些 Agent 只能审查；
- 哪些 Agent 可以运行命令；
- 哪些 Agent 可以提交 Git；
- 哪些 Agent 可以提出分化或重生。

## 5. File Policy

定义文件访问范围：

- 允许读哪些目录；
- 允许写哪些目录；
- 禁止删除哪些文件；
- 关键文件修改是否需要用户确认。

## 6. Command Policy

定义命令执行边界：

- 允许的命令白名单；
- 禁止的危险命令；
- 是否允许安装依赖；
- 是否允许联网；
- 是否必须在沙箱运行。

## 7. Git Policy

定义提交与分支规则：

- 测试失败是否允许 commit；
- 什么情况下创建 checkpoint commit；
- 什么情况下创建 branch；
- 提交信息格式；
- 重生是否必须单独 generation。

## 8. User Confirmation Policy

以下行为应默认需要用户确认：

- 删除大量文件；
- 改变目标方向；
- 创建新分支；
- 进入重生模式；
- 安装高风险插件；
- 执行外部命令；
- 改变能力权限；
- 暂停后恢复到不同计划。

## 9. Retry Policy

避免无意义死循环：

- 同一问题最多修复几次；
- 连续失败是否触发重规划；
- 多次重规划失败是否触发 Rebirth Proposal。

## 10. 关键结论

治理不是削弱 AgentArbor 的自主性，而是让自主性有资格长期存在。
