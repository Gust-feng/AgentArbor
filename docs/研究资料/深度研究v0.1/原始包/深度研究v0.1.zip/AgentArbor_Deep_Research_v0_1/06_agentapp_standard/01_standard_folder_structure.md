# AgentApp 标准目录结构

AgentArbor 孕育出的 AgentApp 应该有标准结构。

```text
agentapp/
├─ arbor.json
├─ docs/
│  ├─ 00_vision.md
│  ├─ 01_requirement.md
│  ├─ 02_mvp_scope.md
│  ├─ 10_architecture.md
│  ├─ 11_tech_stack.md
│  ├─ 12_agent_roles.md
│  ├─ 13_workflow_design.md
│  ├─ 14_data_model.md
│  ├─ 15_test_strategy.md
│  ├─ 16_git_strategy.md
│  ├─ 17_security_policy.md
│  ├─ 18_phase_plan.md
│  ├─ 19_acceptance_matrix.md
│  ├─ debt/
│  │  └─ technical_debt.md
│  └─ evolution/
│
├─ agents/
│  ├─ orchestrator.agent
│  ├─ planner.agent
│  ├─ builder.agent
│  ├─ reviewer.agent
│  └─ tester.agent
│
├─ skills/
├─ capabilities/
├─ workflows/
│  └─ main.workflow.json
│
├─ execution/
│  ├─ current-run.json
│  ├─ task-graph.json
│  └─ history/
│
├─ src/
├─ tests/
├─ evals/
├─ logs/
├─ README.md
└─ Dockerfile
```

## 关键原则

AgentApp 不是只有源码。

它必须有：

- 目标；
- 文档；
- Agent 组织；
- 能力配置；
- 工作流或任务图；
- 测试；
- 评测；
- 运行日志；
- 演化记录；
- Git 历史。

## 最小合格标准

一个 AgentApp 至少需要：

- `arbor.json`；
- `docs/00_vision.md`；
- `docs/18_phase_plan.md`；
- `agents/`；
- `src/`；
- `tests/`；
- `README.md`；
- 可运行命令；
- 至少一条 Git commit 记录。
