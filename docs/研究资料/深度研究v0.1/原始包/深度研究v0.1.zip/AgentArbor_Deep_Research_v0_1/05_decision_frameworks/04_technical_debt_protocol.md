# 技术债协议

## 1. 技术债必须显式存在

AgentArbor 不应让技术债藏在代码里。

每个 AgentApp 应有：

```text
docs/debt/technical_debt.md
```

## 2. 技术债记录格式

```markdown
## Debt ID: debt-001

- Title: Workflow Engine and AgentRuntime are too tightly coupled
- Source: Phase 2 implementation shortcut
- Severity: Medium
- Impact: Harder to support dynamic replanning
- Blocking: Future Branch / Rebirth features
- Proposed Repayment: Split WorkflowEngine from AgentRuntime
- Recommended Phase: Before Evolution System implementation
- Status: Open
```

## 3. 债务等级

- Low：可接受，不影响近期目标。
- Medium：影响扩展，需要排期偿还。
- High：阻塞后续阶段，应尽快重构。
- Critical：根架构风险，可能触发 Rebirth。

## 4. 债务来源

- 为了快速实现 MVP 的捷径；
- 测试缺失；
- 模块边界模糊；
- 能力硬编码；
- 过早抽象；
- 过度依赖某个模型或工具；
- 文档和代码偏离。

## 5. 还债策略

- 每个阶段 Reflect 时检查技术债；
- High 以上债务不能长期跨阶段；
- Critical 债务触发重大重构或 Rebirth Proposal；
- 技术债修复必须配套回归测试。

## 6. 关键结论

技术债不是失败，而是系统成长的伤口。真正的问题不是有债，而是不承认债。
