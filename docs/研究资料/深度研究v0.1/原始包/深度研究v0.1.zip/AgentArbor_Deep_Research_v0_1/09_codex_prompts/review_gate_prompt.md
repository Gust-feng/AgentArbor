# Codex Prompt：Review Gate

请实现 AgentArbor 的 Review Gate。

## 作用

Review Gate 决定一个阶段是否允许进入 Git commit。

## 检查项

- 测试是否通过；
- 构建是否通过；
- 是否违反架构不变量；
- 是否有未记录技术债；
- 文档是否需要更新；
- diff 是否包含危险操作；
- 是否需要用户确认。

## 输出结果

```ts
export type ReviewGateResult = {
  verdict: "allow_commit" | "repair_required" | "refactor_required" | "user_confirmation_required" | "replan_required";
  reasons: string[];
  issues: ReviewIssue[];
  recommendedNextAction: string;
};
```

## 原则

Review Gate 不是为了阻止进展，而是为了防止 AgentArbor 在错误路径上越跑越快。
