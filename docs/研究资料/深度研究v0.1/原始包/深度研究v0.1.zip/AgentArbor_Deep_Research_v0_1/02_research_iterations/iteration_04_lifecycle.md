# Iteration 04：我如何出生、维护、分化、重生

## 初始假设

我从用户需求中生成一个 AgentApp，完成后结束。

## 自我质疑

结束在哪里？如果用户第二天要加功能呢？如果用户改变方向呢？如果当前架构不适合新目标呢？如果用户想基于当前版本做企业版呢？

生成不是生命，只是出生。

## 发现

AgentApp 应该有生命周期：

- Create：从目标中出生。
- Maintain：在同一方向上继续成长。
- Redirect：目标变化时调整主干方向。
- Branch：保留旧主线并分化新版本。
- Rebirth：旧架构无法承载目标时重新生长。

这五种动作构成了 AgentArbor 的演化系统。

## 迭代结论

AgentArbor 不应只生成 Agent，而应管理 AgentApp 的生命史。

## 本轮决策

引入 Evolution System 和 Lineage View。Git branch 不只是分支，而是生命分化。Git commit 不只是提交，而是年轮。
