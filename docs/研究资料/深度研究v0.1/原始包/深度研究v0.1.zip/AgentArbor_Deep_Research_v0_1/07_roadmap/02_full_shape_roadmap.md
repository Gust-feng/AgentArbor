# 完整形态路线图

## Phase 1：Core Runtime

实现：

- EventBus；
- RunState；
- Workflow IR；
- AgentRuntime；
- GitEngine；
- TestRunner；
- Basic Governance。

## Phase 2：Planning & Genesis

实现：

- 目标输入；
- 文档生成；
- 任务图生成；
- AgentApp 标准目录；
- `arbor.json`。

## Phase 3：Execution Loop

实现：

- 多 Agent 执行；
- 文件修改；
- 测试运行；
- Repair；
- commit；
- Reflect。

## Phase 4：Workbench

实现：

- 文件树；
- Agent 图；
- 实时日志；
- Git Timeline；
- 测试面板；
- Diff Viewer；
- 运行控制。

## Phase 5：Capability Fabric

实现：

- built-in capability registry；
- Skill manifest；
- `.agent` manifest；
- MCP connector interface；
- plugin interface；
- capability router。

## Phase 6：Evolution System

实现：

- Patch / Refactor / Redirect；
- Branch；
- Lineage；
- Rebirth Proposal；
- user interruption / resume。

## Phase 7：Advanced Governance

实现：

- command policy；
- file policy；
- model policy；
- user confirmation gates；
- sandbox integration；
- audit logs。

## Phase 8：Desktop & Ecosystem

实现：

- Electron desktop wrapper；
- local workspace manager；
- plugin market；
- community skills；
- enterprise profile。

## 关键原则

每个阶段都必须能独立产生价值，不能等全部做完才有东西。
