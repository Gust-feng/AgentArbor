# AgentArbor Workbench UI

## 1. 产品形态

AgentArbor 的界面应像一个 AI 开发驾驶舱，而不是聊天框。

用户应该看到一个 AgentApp 正在生长：计划、任务、Agent、代码、测试、Git、演化，都在一个空间里发生。

## 2. 核心视图

```text
AgentArbor Workbench
├─ Genesis View
├─ Plan View
├─ Workbench View
├─ Evolution View
├─ Governance View
└─ Capability View
```

## 3. Genesis View

展示：

- 用户目标；
- 需求澄清；
- 场景分析；
- MVP 范围；
- 风险；
- 成功标准。

## 4. Plan View

展示：

- 架构文档；
- 技术栈；
- Agent 角色；
- 动态任务图；
- 验收矩阵；
- 当前计划版本。

## 5. Workbench View

核心工作区。

布局建议：

- 左侧：项目文件树、AgentApp 结构；
- 中间：Agent 图、代码、diff、计划；
- 右侧：Git Timeline、测试结果、能力状态；
- 底部：执行日志、终端输出、事件流；
- 顶部：当前模式、迭代轮次、运行状态、停止按钮。

## 6. Evolution View

展示 AgentApp 的生命谱系：

- main 主线；
- 分支版本；
- 重生代际；
- 每次转向原因；
- 分支间能力差异。

## 7. Governance View

展示：

- 权限策略；
- 危险操作；
- 用户确认点；
- 回滚点；
- 沙箱策略；
- 能力访问记录。

## 8. Capability View

展示：

- 内置能力；
- MCP；
- skills；
- `.agent`；
- plugins；
- 用户自定义能力；
- 能力建议和验证结果。

## 9. UI 的职责

UI 不应该直接执行 Agent 逻辑。

UI 的职责是：

- 发起命令；
- 展示状态；
- 呈现事件；
- 接收用户确认；
- 展示解释；
- 暴露治理边界。

## 10. 关键结论

AgentArbor 的 UI 应该让用户感到：

> 我不是在操作一个工具，而是在观察并修剪一个正在生长的软件生命。
