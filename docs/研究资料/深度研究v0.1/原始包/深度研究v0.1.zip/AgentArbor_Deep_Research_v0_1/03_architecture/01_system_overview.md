# 整体系统架构

## 1. 总览

AgentArbor 的完整架构可以分为八层：

```text
AgentArbor
├─ Workbench Layer        工作台层
├─ Autonomy Kernel        自主内核
├─ Agent Organization     Agent 组织层
├─ Capability Fabric      能力织网层
├─ Execution Runtime      执行运行时
├─ Verification System    验证系统
├─ Evolution System       演化系统
└─ Governance System      治理系统
```

这八层不是简单上下游关系，而是围绕一个目标不断循环。

## 2. 信息流

用户输入的不是步骤，而是目标。

目标进入 Autonomy Kernel 后，系统会读取当前状态，分析差距，生成行动候选。然后动态形成 Workflow Graph，交给 Agent Organization 和 Execution Runtime 执行。执行结果进入 Verification System，验证结果进入 Reflection 与 Evolution System，最后决定继续、修复、重构、转向、分化、重生、暂停或完成。

## 3. 工作台层

Workbench 是用户看到的界面。它展示：

- 当前目标；
- 动态任务图；
- Agent 组织；
- 实时执行日志；
- Git 时间线；
- 测试结果；
- 文件变更；
- 演化谱系；
- 用户确认点。

Workbench 不应该主导流程，它只是让用户看见系统的生长过程。

## 4. 自主内核

自主内核负责系统的元循环：Observe、Orient、Plan、Act、Verify、Reflect、Evolve。

它不直接写代码，而是决定系统下一步应该做什么。

## 5. Agent 组织层

Agent 组织层负责将任务分派给合适角色。推荐三层：RootOrchestrator、PhaseLeadAgent、WorkerAgents。

## 6. 能力织网层

能力织网让系统不被固定能力限制。它统一管理 MCP、skills、`.agent`、plugins、内置工具和用户自定义能力。

## 7. 执行运行时

执行运行时负责真正动手：读写文件、调用模型、调用工具、运行命令、执行测试、提交 Git。

## 8. 验证系统

验证系统决定结果是否可保留。没有验证，AgentArbor 会变成自信的生成器；有验证，它才有收敛能力。

## 9. 演化系统

演化系统支持 Patch、Refactor、Redirect、Branch、Rebirth。它让 AgentApp 不只是被创建，而是能继续成长。

## 10. 治理系统

治理系统限制危险动作、权限边界、文件范围、命令执行、用户确认点、最大重试次数和提交条件。

## 11. 核心设计判断

AgentArbor 不是“前端 + 后端 + Agent 调用”。它是一个围绕目标形成自主判断的系统。前端只是驾驶舱，真正的灵魂在 Autonomy Kernel、Evolution System 和 Governance System。
