# 演化决策矩阵

AgentArbor 必须知道什么时候 Patch、Refactor、Redirect、Branch、Rebirth。

## 决策表

| 情况 | 推荐动作 | 原因 |
|---|---|---|
| 局部测试失败 | Patch | 问题范围小，目标不变 |
| 类型错误或小 bug | Patch | 成本低，可快速修复 |
| 功能能跑但结构变差 | Refactor | 需要偿还技术债 |
| 模块边界反复被破坏 | Refactor | 架构约束失效，需要整理 |
| 用户改变产品方向 | Redirect | 目标变了，先改文档和计划 |
| 新需求与旧主线都合理 | Branch | 避免污染主线 |
| 用户要求企业版/轻量版 | Branch | 分化版本更清晰 |
| 连续修复失败 | Rebirth Proposal | 当前路径可能错误 |
| 技术债阻塞后续阶段 | Rebirth 或重大 Refactor | 根部可能需要重建 |
| 旧架构无法支持新目标 | Rebirth | 继续修会更贵 |
| 用户主动停止 | Suspend | 保存状态，等待新指令 |

## 评分模型

每个候选动作根据以下维度评分：

- goalImpact：对目标推进程度；
- risk：风险；
- reversibility：可逆性；
- effort：预计成本；
- confidence：成功置信度；
- debtImpact：技术债影响；
- lineageImpact：对谱系影响；
- userIntentFit：是否贴合用户意图。

## 决策原则

1. 小问题优先 Patch。
2. 结构问题优先 Refactor。
3. 目标变化优先 Redirect。
4. 多方向并存优先 Branch。
5. 根架构失效优先 Rebirth。
6. 高风险动作必须用户确认。

## 关键结论

AgentArbor 的成熟不是永远继续，而是知道什么时候该停、该修、该分、该重来。
