# Event Model：事件模型

AgentArbor 的运行过程必须事件化。

## 为什么

事件是：

- UI 实时展示的依据；
- 自主内核观察状态的依据；
- 反思与演化的依据；
- Git 年轮之外的细粒度历史；
- 中断恢复的基础。

## 事件示例

```json
{
  "eventId": "evt_001",
  "runId": "run_2026_04_27_001",
  "type": "agent.started",
  "timestamp": "2026-04-27T10:25:00Z",
  "actor": "PlannerAgent",
  "message": "Generating phase plan",
  "payload": {
    "phase": "planning"
  }
}
```

## 事件类型

```text
run.started
run.paused
run.resumed
run.completed
user.interrupted
user.changed_goal
agent.created
agent.started
agent.completed
agent.failed
task.created
task.started
task.completed
task.failed
workflow.generated
workflow.revised
workflow.superseded
file.changed
test.started
test.failed
test.passed
review.completed
debt.detected
git.committed
git.branch_created
evolution.patch_selected
evolution.refactor_selected
evolution.redirect_selected
evolution.branch_selected
evolution.rebirth_proposed
governance.blocked
governance.user_confirmation_required
```

## 事件原则

1. 所有关键动作必须有事件。
2. 事件不可直接删除。
3. 事件可用于重放和恢复。
4. UI 不应该自己猜状态，应从事件和 snapshot 渲染。
