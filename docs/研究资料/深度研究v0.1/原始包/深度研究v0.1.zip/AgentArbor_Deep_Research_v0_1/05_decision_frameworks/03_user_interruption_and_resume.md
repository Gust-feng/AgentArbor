# 用户主动停止与后续迭代

## 1. 用户停止不是失败

用户主动停止自主迭代，不应该被视为异常，而应视为系统进入 Suspended State。

## 2. 停止流程

当用户停止：

1. 停止派发新任务。
2. 当前危险动作进入安全停止。
3. 保存 workspace snapshot。
4. 保存当前任务图状态。
5. 记录事件历史。
6. 生成 suspension-report.md。
7. 给出恢复选项。

## 3. suspension-report.md 内容

应包括：

- 停止时间；
- 当前目标；
- 当前阶段；
- 已完成任务；
- 未完成任务；
- 当前风险；
- 未提交变更；
- 测试状态；
- 推荐后续路径。

## 4. 用户后续选择

| 用户选择 | 系统动作 |
|---|---|
| 继续原计划 | 从 checkpoint 恢复 |
| 修改目标 | Redirect |
| 保留当前并开新方向 | Branch |
| 当前做歪了 | Replan / Rebirth |
| 人工接管 | Manual Mode |
| 要求重新评估 | Observe + Reflect |

## 5. Manual Mode

用户可能希望自己或外部 AI 接管一段时间。

AgentArbor 应进入 Manual Mode：

- 继续记录 Git 和文件变化；
- 暂停自主任务派发；
- 后续恢复时重新观察当前状态；
- 将人工变更纳入历史。

## 6. 恢复原则

恢复时不能假设旧计划仍然有效。

必须先：

```text
Observe → Orient → Reflect → Decide Resume / Replan / Redirect
```

## 7. 关键结论

用户停止不是中断生命，而是园丁暂时按住了树枝。AgentArbor 应保存姿态，等待下一次生长方向。
