# AgentArbor Deep Research v0.1

这是一份面向 **AgentArbor 完整形态** 的深度研究文件夹。

它不是一份普通的功能清单，也不是“AI 写代码平台”的包装文案，而是把 AgentArbor 视为一个尚未出生的系统，让它从目标、自主性、演化、治理、能力、Agent 组织、Git 年轮、技术债与重生机制等角度，自己反复逼问自己：

> 我到底是什么？
> 我凭什么自主？
> 我如何孕育 Agent？
> 我如何避免长歪？
> 我什么时候继续，什么时候修剪，什么时候分化，什么时候重生？

## 推荐阅读顺序

1. `01_foundation/01_vision.md` 先读愿景。
2. `01_foundation/02_design_principles.md` 看 AgentArbor 的底层原则。
3. `02_research_iterations/` 看这次“自助迭代式研究”的阶段性结论。
4. `03_architecture/01_system_overview.md` 看整体架构。
5. `03_architecture/02_autonomy_kernel.md` 看自主性核心。
6. `05_decision_frameworks/01_evolution_decision_matrix.md` 看维护、转向、分化、重生的选择依据。
7. `06_agentapp_standard/` 看 AgentArbor 孕育出来的 AgentApp 应该是什么。
8. `08_diagrams/` 是可复制到 Mermaid 工具中的图。
9. `09_codex_prompts/` 是给后续 AI 开发工具使用的开发简报。

## 一句话结论

AgentArbor 不是固定工作流平台，而是一个 **目标驱动、Git 记录、Agent 执行、能力可扩展、验证可收敛、演化可追溯的 AgentApp 生命系统**。

它的核心不是“让 AI 自动写完代码”，而是：

> 让一个想法在目标、反馈、能力、治理和 Git 年轮之间，逐渐长成一个能够工作的多 Agent 系统。
