# 核心概念词典

## AgentArbor

基于 Git 演化的 AgentApp 孕育、开发、维护、分化与重生平台。

## AgentApp

由 AgentArbor 孕育出来的多 Agent 应用工程。它不是 Prompt 集合，而是包含目标、文档、Agent 定义、能力配置、源码、测试、日志、Git 历史和演化谱系的完整工程。

## Autonomy Kernel

自主内核。负责目标管理、状态观察、差距分析、行动候选生成、决策、反思和演化判断。

## Meta Loop

系统固定的元循环：Observe → Orient → Plan → Act → Verify → Reflect → Evolve。它不是业务模板，而是自主系统的心跳。

## Workflow Graph

动态任务图。由 AgentArbor 根据目标与当前状态生成，可在执行中被修改、重排、扩展或废弃。

## Capability Fabric

能力织网。统一管理 MCP、skills、`.agent`、plugins、built-in tools 和用户自定义能力。

## `.agent`

Agent 定义文件。描述某个 Agent 的角色、目标、能力、权限、模型、记忆范围和输入输出格式。

## Skill

可复用的专业能力包。可以被 Agent 调用，包含说明、schema、工具依赖、示例、评测样例和失败模式。

## Plugin

扩展 AgentArbor 本体的模块。可提供新 UI、新能力、新运行时、新模板、新治理策略等。

## Lineage

谱系。记录 AgentApp 的血缘、分支、代际和重生关系。

## Patch

小修补。用于局部 bug、测试失败、类型错误等。

## Refactor

重构。用于代码能跑但结构变差、技术债变高的情况。

## Redirect

转向。用户或系统发现目标方向变化，需要先更新目标和计划，再修改代码。

## Branch

分化。保留当前主线，同时开出新版本，如企业版、轻量版、实验版。

## Rebirth

重生。旧架构已不适合目标时，保留经验和核心需求，重新生成新一代工程。

## Governance

治理。对权限、安全、危险操作、人工确认、最大重试、提交条件等进行约束。
