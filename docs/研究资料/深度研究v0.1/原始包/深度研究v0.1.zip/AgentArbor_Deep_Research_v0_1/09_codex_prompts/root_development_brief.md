# Codex Brief：AgentArbor 根开发简报

你正在开发 AgentArbor。

AgentArbor 不是普通 AI 编程助手，不是固定工作流平台，也不是 Bot 搭建器。

它是一个基于 Git 演化的 AgentApp 生命周期平台。

## 核心目标

实现一个系统，使用户目标可以被转化为：

- 文档；
- 动态任务图；
- 多 Agent 执行；
- 测试验证；
- Git commit；
- 反思迭代；
- 维护、转向、分化、重生能力。

## 不可违反原则

1. 工作流不能写死为固定模板。
2. UI 不能直接控制 Agent 逻辑。
3. 所有关键动作必须事件化。
4. 测试失败不能进入正式阶段提交。
5. 重生和分化必须需要用户确认。
6. Agent 不能越权调用能力。
7. 计划是当前假设，不是真理。
8. Git 是时间轴，不是普通存储。

## 推荐第一版结构

```text
apps/web
apps/server
packages/core
packages/git-engine
packages/workspace
packages/model-router
packages/evaluator
packages/capability-fabric
packages/shared
```

## 第一版目标

先跑通：

```text
目标 → 计划 → 动态任务图 → Agent 执行 → 测试 → 修复 → Git commit → Reflect
```

不要一开始实现完整生态。
